package com.marwari.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Launcher screen. This is a temporary View-based screen; it will be replaced
 * by Compose screens (Home, Translation, Privacy) in the next step.
 *
 * It only reports keyboard status that Android confirms. It never assumes the
 * keyboard is enabled or selected.
 */
class MainActivity : Activity() {

    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val padding = (24 * resources.displayMetrics.density).toInt()
        val ink = Color.parseColor("#1F2A24")

        val title = TextView(this).apply {
            text = "Marwari Keyboard"
            textSize = 26f
            setTextColor(ink)
        }

        statusView = TextView(this).apply {
            textSize = 16f
            setTextColor(ink)
        }

        val enableButton = Button(this).apply {
            text = "Enable Keyboard"
            setOnClickListener {
                // Opens the system list of input methods so the user can turn this one on.
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        val selectButton = Button(this).apply {
            text = "Select Keyboard"
            setOnClickListener {
                // Opens the system keyboard picker. Only works after the keyboard is enabled.
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
            addView(title)
            addView(statusView)
            addView(enableButton)
            addView(selectButton)
        }
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val currentIme = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.DEFAULT_INPUT_METHOD
        ).orEmpty()
        val selected = currentIme.startsWith(packageName)

        statusView.text = when {
            !enabled -> "Keyboard is not enabled yet."
            !selected -> "Keyboard is enabled but not selected."
            else -> "Keyboard is enabled and selected."
        }
    }
}
