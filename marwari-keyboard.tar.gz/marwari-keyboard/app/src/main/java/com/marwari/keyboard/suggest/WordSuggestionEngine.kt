package com.marwari.keyboard.suggest

/**
 * One dictionary entry.
 * @param word preferred spelling, lowercase. This is what gets inserted.
 * @param meaning short English gloss, for future use in the UI.
 * @param variants other accepted spellings. Matched when typing, but never inserted.
 */
data class DictionaryEntry(
    val word: String,
    val meaning: String = "",
    val variants: List<String> = emptyList()
)

/**
 * Finds dictionary words that start with what the user has typed so far.
 *
 * Matching is case-insensitive prefix matching. Results keep dictionary order,
 * so put the most common words first. A linear scan is fine for a few thousand
 * entries; switch to a trie if the dictionary grows much larger.
 */
class WordSuggestionEngine(entries: List<DictionaryEntry>) {

    private val entries: List<DictionaryEntry> = entries.toList()

    /**
     * @param typed the current word, without spaces or punctuation.
     * @return up to [limit] canonical words. Empty if nothing matches.
     */
    fun suggest(typed: String, limit: Int = MAX_SUGGESTIONS): List<String> {
        val prefix = typed.trim().lowercase()
        if (prefix.isEmpty() || limit <= 0) return emptyList()

        val results = LinkedHashSet<String>()
        for (entry in entries) {
            val matches = entry.word.startsWith(prefix) ||
                entry.variants.any { it.startsWith(prefix) }
            // Do not suggest a word back when it is already fully typed.
            if (matches && entry.word != prefix) {
                results.add(entry.word)
            }
            if (results.size >= limit) break
        }
        return results.toList()
    }

    companion object {
        const val MAX_SUGGESTIONS = 3

        /** The word being typed: the run of letters right before the cursor. */
        fun currentWord(textBeforeCursor: CharSequence): String =
            textBeforeCursor.takeLastWhile { it.isLetter() }.toString()

        /** Keeps the capitalisation the user typed: "M" -> "Mharo", "MH" -> "MHARO". */
        fun matchCase(suggestion: String, typed: String): String = when {
            typed.isEmpty() -> suggestion
            typed.length > 1 && typed.all { it.isUpperCase() } -> suggestion.uppercase()
            typed.first().isUpperCase() -> suggestion.replaceFirstChar { it.uppercaseChar() }
            else -> suggestion
        }
    }
}
