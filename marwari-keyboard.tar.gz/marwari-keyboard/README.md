# Marwari Keyboard (Android MVP, step 1)

This is the first part of the project: the Gradle scaffold, the keyboard (IME) service, the word suggestion engine, the local dictionary, and unit tests. The translation screen and the Compose UI come next.

## Status

| Part | State |
|---|---|
| Gradle / manifest / IME metadata | Written. Not yet built on a machine with the Android SDK. |
| Keyboard service (QWERTY, shift, backspace, space, enter, symbols) | Written. Not yet tested on a device. |
| Suggestions (prefix, case-insensitive, tap to replace) | Written. Unit tests written, not yet run. |
| Dictionary (about 130 entries) | Seed list. Needs review by native Marwari speakers. |
| Launcher screen (enable and select buttons, status) | Written. Temporary View-based screen. |
| Translation screen and backend | Not started. |
| WhatsApp and physical-device compatibility | Not tested. |

## Requirements

- Android Studio Ladybug (2024.2) or newer, with Android SDK 34 installed.
- JDK 17 (Android Studio bundles one).

## Build

1. Open the `marwari-keyboard` folder in Android Studio.
2. Let Gradle sync. If Android Studio asks for a Gradle wrapper, choose "Use gradle wrapper" or run `gradle wrapper` once in the project folder.
3. Run unit tests: `./gradlew :app:testDebugUnitTest`
4. Build the debug APK: `./gradlew :app:assembleDebug`
   The APK is written to `app/build/outputs/apk/debug/`.

## Install and enable the keyboard

1. Install the debug APK on an Android phone (Android 7.0 or newer). Allow installs from your file manager or Android Studio.
2. Open **Marwari Keyboard**.
3. Tap **Enable Keyboard**. In system settings, turn on **Marwari Keyboard**.
4. Return to the app. It should say "enabled". Tap **Select Keyboard** and choose Marwari Keyboard.
5. Open any text field, such as a notes app, and switch to Marwari Keyboard using the keyboard switcher.

The app only shows "enabled and selected" when Android reports it. Some phones show extra security warnings for sideloaded apps; these are expected for a debug build.

## Editing the dictionary

Edit `app/src/main/assets/marwari_dictionary.json`. Each entry is:

```json
{"word": "mharo", "meaning": "my / our", "variants": ["mhaaro"]}
```

- `word` is the spelling that gets inserted. Use lowercase.
- `variants` are other spellings. They help matching but are never inserted.
- The file is read once when the keyboard starts. Rebuild the app after editing.

Spellings and meanings are seed values, not an official standard. Marwari has regional and spelling variation. Please have native speakers review the list before wider release.

## Privacy

- The keyboard does not store, log, or send what you type.
- No suggestions are shown in password fields.
- No permissions are requested. INTERNET will be added only with the translation feature.

## Known limitations

- Suggestions use only the letters right before the cursor. Multi-word entries like "ram ram" are matched by their first word.
- Long-press keys, the emoji key, and voice input are not implemented.
- The launcher screen uses plain Android Views. It will be rebuilt in Jetpack Compose.
- No app icon yet. The default icon is used.
